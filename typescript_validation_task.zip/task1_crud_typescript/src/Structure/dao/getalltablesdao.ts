import { queryExecution } from "../../Execution/queryExecution";
import { display_alltask_type } from "../../Types/TaskTableType";
import { quries } from "../../quries/sqlquries";

//getAllTask
export async function getAllTaskdao(): Promise<display_alltask_type> {
  const result = queryExecution(quries.getalluserquries);
  return result;
}
