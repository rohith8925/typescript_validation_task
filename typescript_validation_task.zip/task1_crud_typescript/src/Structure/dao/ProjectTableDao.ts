import { quries } from "../../quries/sqlquries";
import { queryExecution } from "../../Execution/queryExecution";
import {
  delete_projecttable_type,
  insert_projecttable_type,
  projecttable_type,
  update_projecttable_type,
} from "../../Types/ProjectTableTypes";
import { message } from "../../Types/UserTableTypes";
import { queryMessage } from "../../messages/message";

export async function getAllProjectDetailsDao(): Promise<projecttable_type> {
  const result = await queryExecution(quries.display_project_query);
  return result;
}

export async function insertProjectDetailsDao(
  obj: insert_projecttable_type
): Promise<message> {
  const result = await queryExecution(
    quries.insert_project_query,
    [obj.project_id, obj.project_name, obj.project_description],
    { autoCommit: true }
  );
  if (result.rowsAffected) {
    return {
      message: queryMessage.insertMessage,
      rowsAffected: result.rowsAffected,
    };
  }
  return result;
}

export async function updateProjectDetailsDao(
  obj: update_projecttable_type
): Promise<message> {
  const result = await queryExecution(
    quries.Update_project_query,
    [obj.project_name, obj.project_id],
    { autoCommit: true }
  );
  console.log(result.rowsAffected);
  if (result.rowsAffected) {
    return {
      message: queryMessage.updateMessage,
      rowsAffected: result.rowsAffected,
    };
  }
  return result;
}

export async function deleteProjectDetailsDao(
  obj: delete_projecttable_type
): Promise<message> {
  const result = await queryExecution(
   quries.delete_project_query,
    [obj.project_id],
    { autoCommit: true }
  );
  if (result.rowsAffected) {
    return {
      message: queryMessage.deleteMessage,
      rowsAffected: result.rowsAffected,
    };
  }
  return result;
}
