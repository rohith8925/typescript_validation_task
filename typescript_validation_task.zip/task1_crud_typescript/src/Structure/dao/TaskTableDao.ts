import { queryExecution } from "../../Execution/queryExecution";
import {
  tasktable_type,
  insert_tasktable_type,
  update_tasktable_type,
  delete_tasktable_type,
} from "../../Types/TaskTableType";
import { message } from "../../Types/UserTableTypes";
import { queryMessage } from "../../messages/message";
import { quries } from "../../quries/sqlquries";

export async function getAllTaskDetailsDao(): Promise<tasktable_type> {
  const result = await queryExecution(quries.display_task_query);
  return result;
}

export async function insertTaskDetailsDao(
  obj: insert_tasktable_type
): Promise<any> {
  try {
    const result = await queryExecution(
      quries.insert_task_query,
      [
        obj.task_id,
        obj.task_title,
        obj.task_description,
        obj.assignedTo,
        obj.dueDate,
        obj.status,
        obj.project_id,
      ],
      { autoCommit: true }
    );
    if (result.rowsAffected) {
      return {
        message: queryMessage.insertMessage,
        rowsAffected: result.rowsAffected,
      };
    }
  } catch (error) {
    console.error("-----", error);
    return {
      error: {
        message: "Eroor in date format",
        details: error,
      },
    };
  }
}

export async function updateTaskDetailsDao(
  obj: update_tasktable_type
): Promise<message> {
  const result = await queryExecution(
    quries.Update_task_query,
    [obj.status, obj.task_id],
    { autoCommit: true }
  );
  if (result.rowsAffected) {
    return {
      message: queryMessage.updateMessage,
      rowsAffected: result.rowsAffected,
    };
  }
  return result;
}

export async function deleteTaskDetailsDao(
  obj: delete_tasktable_type
): Promise<message> {
  const result = await queryExecution(quries.delete_task_query, [obj.task_id], {
    autoCommit: true,
  });
  if (result.rowsAffected) {
    return {
      message: queryMessage.deleteMessage,
      rowsAffected: result.rowsAffected,
    };
  }
  return result;
}
