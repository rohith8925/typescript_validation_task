import {
  usertable_type,
  message,
  update_usertable_type,
  delete_usertable_type,
} from "../../Types/UserTableTypes";

import { quries } from "../../quries/sqlquries";
import { queryExecution } from "../../Execution/queryExecution";
import { queryMessage } from "../../messages/message";

//loginUser
export const loginUsersDetailsDao = async (
  user_name: string,
  user_password: string
) => {
  let result = await queryExecution(
    quries.loginUserQuery,
    {
      user_name: { val: user_name },
      user_password: { val: user_password },
    },
    { autoCommit: true }
  );
  return result;
};

export const getAllUserDetailsDao=async() =>{
  try{
    const viewdata =await queryExecution(quries.display_user_query);
    console.log(viewdata);
    return viewdata;
  }catch(error){
    console.log(error);
    throw error;
  }
}

export async function insertUserDetailsDao(
  obj: usertable_type
): Promise<message> {
  const result = await queryExecution(
    quries.insert_user_query,
    [obj.user_id, obj.user_name, obj.user_email, obj.user_password],
    { autoCommit: true }
  );
  if (result.rowsAffected) {
    return {
      message: queryMessage.insertMessage,
      rowsAffected: result.rowsAffected,
    };
  }
  return result;
}

export async function updateUserDetailsDao(
  obj: update_usertable_type
): Promise<message> {
  const result = await queryExecution(
    quries.Update_user_query,
    [obj.user_name, obj.id],
    { autoCommit: true }
  );
  if (result.rowsAffected) {
    return {
      message: queryMessage.updateMessage,
      rowsAffected: result.rowsAffected,
    };
  }
  return result;
}

export async function deleteUserDetailsDao(
  obj: delete_usertable_type
): Promise<message> {
  const result = await queryExecution(quries.delete_user_query, [obj.id], {
    autoCommit: true,
  });
  if (result.rowsAffected) {
    return {
      message: queryMessage.deleteMessage,
      rowsAffected: result.rowsAffected,
    };
  }
  return result;
}
