import {
  loginUsersDetailsDao,
  deleteUserDetailsDao,
  getAllUserDetailsDao,
  insertUserDetailsDao,
  updateUserDetailsDao,
} from "../dao/UserTableDao";
import {
  update_usertable_type,
  usertable_type,
} from "../../Types/UserTableTypes";
import jwt from 'jsonwebtoken'

//login
export const loginUserDetailsService = async (
  user_name: string,
  user_password: string
) => {
  const result = await loginUsersDetailsDao(user_name, user_password);
  if (!process.env.TOKEN_KEY) {
    throw new Error("🤷‍♂️Token key is not found in the '.env' file");
  }
  const gentoken = jwt.sign(
    { user_name: user_name, user_password: user_password },
    process.env.TOKEN_KEY
  );
  console.log("----------", gentoken);
  result.rows[0].Token = gentoken;
  console.log("--------Token--------", result);
  return result.rows;
};

//allUserService
export const getAllUserDetailsService=async()=> {
  const result = await getAllUserDetailsDao();
  return result;
}

//inserUserService
export async function insertUserDetailsService(obj: usertable_type) {
  const result = await insertUserDetailsDao(obj);
  return result;
}

//updateUserService
export async function updateUserDetailsService(obj: update_usertable_type) {
  const result = await updateUserDetailsDao(obj);
  return result;
}

//deleteUserService
export async function deleteUserDetailsService(obj: any) {
  const result = await deleteUserDetailsDao(obj);
  return result;
}
