import {
  delete_tasktable_type,
  insert_tasktable_type,
  update_tasktable_type,
} from "../../Types/TaskTableType";
import {
  deleteTaskDetailsDao,
  getAllTaskDetailsDao,
  insertTaskDetailsDao,
  updateTaskDetailsDao,
} from "../dao/TaskTableDao";

//readTaskDetailsService
export async function getAllTaskDetailsService() {
  const result = await getAllTaskDetailsDao();
  return result;
}

//insertTaskDetailsService
export async function insertTaskDetailsService(obj: insert_tasktable_type) {
  const result = await insertTaskDetailsDao(obj);
  return result;
}

//updateTaskDetailsService
export async function updateTaskDetailsService(obj: update_tasktable_type) {
  const result = await updateTaskDetailsDao(obj);
  return result;
}

//deleteTaskDetailsService
export async function deleteTaskDetailsService(obj: delete_tasktable_type) {
  const result = await deleteTaskDetailsDao(obj);
  return result;
}
