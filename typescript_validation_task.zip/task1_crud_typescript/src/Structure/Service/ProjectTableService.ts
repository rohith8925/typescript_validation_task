import {
  insert_projecttable_type,
  update_projecttable_type,
  delete_projecttable_type,
} from "../../Types/ProjectTableTypes";

import {
  deleteProjectDetailsDao,
  getAllProjectDetailsDao,
  insertProjectDetailsDao,
  updateProjectDetailsDao,
} from "../dao/ProjectTableDao";

//readProjectDetailsService
export async function getAllProjectDetailsService() {
  const result = await getAllProjectDetailsDao();
  return result;
}

//insertProjectDetailsService
export async function insertProjectDetailsService(
  obj: insert_projecttable_type
) {
  const result = await insertProjectDetailsDao(obj);
  return result;
}

//updateProjectDetailsService
export async function updateProjectDetailsService(
  obj: update_projecttable_type
) {
  const result = await updateProjectDetailsDao(obj);
  return result;
}

//deleteProjectDetailsService
export async function deleteProjectDetailsService(
  obj: delete_projecttable_type
) {
  const result = await deleteProjectDetailsDao(obj);
  return result;
}
