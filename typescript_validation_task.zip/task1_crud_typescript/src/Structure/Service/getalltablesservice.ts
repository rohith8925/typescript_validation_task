import { getAllTaskdao } from "../dao/getalltablesdao";

//getAllTaskService
export async function getAlltaskservice() {
  const result = await getAllTaskdao();
  return result;
}
