import {
  loginUserDetailsService,
  deleteUserDetailsService,
  getAllUserDetailsService,
  insertUserDetailsService,
  updateUserDetailsService,
} from "../Service/UserTableService";
import { Request, Response } from "express";

//loginUserDetails
export const loginUserDetailsController = async (req: Request,res: Response) => {
  const result = await loginUserDetailsService(req.body.user_name,req.body.user_password);
  console.log("----PersonLogin----", result);
  res.json(result);
};

//allUser
export const getAllUserDetailsController=async(req: Request, res: Response)=> {
  const result = await getAllUserDetailsService();
  return res.json(result);
  //  result;
}

//insertUser
export async function insertUserDetailsController(req: Request, res: Response) {
  const result = await insertUserDetailsService(req.body);
  return res.json(result);
  // return result;
}

//updateUser
export async function updateUserDetailsController(req: Request, res: Response) {
  const result = await updateUserDetailsService(req.body);
  res.json(result);
  return result;
}

//deleteUser
export async function deleteUserDetailsController(req: Request, res: Response) {
  const result = await deleteUserDetailsService(req.query);
  res.json(result);
  return result;
}
