import { Request, Response } from "express";
import { getAlltaskservice } from "../Service/getalltablesservice";

//AlltaskDetails
export async function getAllTaskController(req: Request, res: Response) {
  const result = await getAlltaskservice();
  res.json(result);
}
