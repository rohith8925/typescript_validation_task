import { Request, Response } from "express";
import {
  deleteTaskDetailsService,
  getAllTaskDetailsService,
  insertTaskDetailsService,
  updateTaskDetailsService,
} from "../Service/TaskTableService";

//allTaskDetails
export async function getAllTaskDetailsController(req: Request, res: Response) {
  const result = await getAllTaskDetailsService();
  res.json(result);
  return result;
}

//inserTaskDetails
export async function insertTaskDetailsController(req: Request, res: Response) {
  const result = await insertTaskDetailsService(req.body);
  res.json(result);
  return result;
}

//updateTaskDetails
export async function updateTaskDetailsController(req: Request, res: Response) {
  const result = await updateTaskDetailsService(req.body);
  res.json(result);
  return result;
}

//deleteTaskDetails
export async function deleteTaskDetailsController(req: Request, res: Response) {
  const result = await deleteTaskDetailsService(req.body);
  res.json(result);
  return result;
}
