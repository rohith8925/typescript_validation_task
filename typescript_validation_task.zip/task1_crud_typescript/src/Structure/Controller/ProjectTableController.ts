import { Request, Response } from "express";
import {
  deleteProjectDetailsService,
  getAllProjectDetailsService,
  insertProjectDetailsService,
  updateProjectDetailsService,
} from "../Service/ProjectTableService";

//allProjectDetails
export async function getAllProjectDetailsController(
  req: Request,
  res: Response
) {
  const result = await getAllProjectDetailsService();
  res.json(result);
  return result;
}

//insertProject
export async function insertProjectDetailsController(
  req: Request,
  res: Response
) {
  const result = await insertProjectDetailsService(req.body);
  res.json(result);
  return result;
}

//updateProject
export async function updateProjectDetailsController(
  req: Request,
  res: Response
) {
  const result = await updateProjectDetailsService(req.body);
  res.json(result);
  return result;
}

//eleteProject
export async function deleteProjectDetailsController(
  req: Request,
  res: Response
) {
  const result = await deleteProjectDetailsService(req.body);
  res.json(result);
  return result;
}
