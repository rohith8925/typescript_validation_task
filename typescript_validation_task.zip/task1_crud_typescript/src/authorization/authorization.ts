import { Request, Response } from "express";
import { queryMessage } from "../messages/message";
import jwt from "jsonwebtoken";
export const validToken = async (
  req: Request,
  res: Response,
  next: Function
) => {
  let token = req.rawHeaders[1].split(" ")[1];
  console.log(token);
  if (!token) {
    return res.send(queryMessage.tokenValidation);
  }
  try {
    if (!process.env.TOKEN_KEY) {
      throw new Error(queryMessage.tokenEnv);
    }
    if (token) {
      jwt.verify(token, process.env.TOKEN_KEY);
    }
  } catch (error) {
    return res.status(401).send(queryMessage.validateUser); // Unauthorize response !!!
  }
  return next();
};
