import z from "zod";

//joinschema
export const allTaskDetails = z.object({
  task_id: z.number(),
  task_title: z.string(),
  task_description: z.string(),
  assigned_to: z.string(),
  duedate: z.date(),
  status: z.string(),
  project_name: z.string(),
});
