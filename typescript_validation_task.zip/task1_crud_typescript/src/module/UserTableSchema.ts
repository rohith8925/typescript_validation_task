import z from "zod";
import { quries } from "../quries/sqlquries";
import { queryExecution } from "../Execution/queryExecution";
import { userTableMessages } from "../messages/message";

export const usertableDetails = z.object({
  user_id: z.number(),
  user_name: z.string().refine(
    async (username) => {
      const result = await queryExecution(quries.select_user_name_query, [username]);
      if (result.rows.length===0) {
        return true;
      }
      return false;
    },
    { message: userTableMessages.name }
  ),
  user_email: z.string().email(),
  user_password: z
    .string()
    .min(8, { message: userTableMessages.minimum })
    .max(16, { message: userTableMessages.maximum })
    .regex(/[A-Z]/, { message: userTableMessages.uppercase })
    .regex(/[a-z]/, { message: userTableMessages.lowercase })
    .regex(/[0-9]/, { message: userTableMessages.numeric })
    .regex(/[!@#$%^&*|+~/]/, { message: userTableMessages.specialcharacter }),
});

export const updateUserTableDetails = z.object({
  user_name: z.string().refine(
    async (username) => {
      const result = await queryExecution(quries.select_user_name_query, [
        username,
      ]);
      if (result.rows.length) {
        return false;
      }
      return true;
    },
    { message: userTableMessages.name }
  ),
  id: z.number().refine(
    async (id) => {
      const result = await queryExecution(quries.select_user_id_query, [
        id,
      ]);
      if (result.rows.length) {
        return true;
      }
      return false;
    },
    { message: userTableMessages.id }
  ),
});

export const deleteUserTableDetails = z.object({
  id: z.string(),
});
