import z from "zod";
import { quries } from "../quries/sqlquries";
import { queryExecution } from "../Execution/queryExecution";
import { projectTableMessages } from "../messages/message";

//insert project
export const projectTableDetails = z.object({
  project_id: z.number(),
  project_name: z
    .string()
    .min(5, { message: projectTableMessages.nameminimum })
    .max(30, { message: projectTableMessages.namemaximum })
    .refine(
      async (name) => {
        const result = await queryExecution(
          quries.select_project_name_query,
          [name]
        );
        if (result.rows.length) {
          return false;
        }
        return true;
      },
      { message: projectTableMessages.name }
    ),
  project_description: z
    .string()
    .min(10, { message: projectTableMessages.descminimum })
    .max(300, { message: projectTableMessages.descmaximum }),
});

//updateProject
export const updateTableDetails = z.object({
  project_name: z
    .string()
    .min(5, { message: projectTableMessages.nameminimum })
    .max(30, { message: projectTableMessages.namemaximum })
    .refine(
      async (name) => {
        const result = await queryExecution(
          quries.select_project_name_query,
          [name]
        );
        if (result.rows.length) {
          return false;
        }
        return true;
      },
      { message: projectTableMessages.name }
    ),
  project_id: z.number().refine(
    async (id) => {
      const result = await queryExecution(
        quries.select_project_id_query,
        [id]
      );
      if (result.rows.length) {
        return true;
      }
      return false;
    },
    { message: projectTableMessages.id }
  ),
});

//deleteProject
export const deleteTableDetails = z.object({
  project_id: z.number(),
});
