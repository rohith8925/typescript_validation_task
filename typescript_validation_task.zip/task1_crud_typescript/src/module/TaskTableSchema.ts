import z from "zod";
import { queryExecution } from "../Execution/queryExecution";
import { quries } from "../quries/sqlquries";
import { taskTableMessages } from "../messages/message";

//insertTask
export const taskTableDetails = z.object({
  task_id: z.number(),
  task_title: z.string(),
  task_description: z.string(),
  assignedTo: z.number().refine(
    async (assigned_to) => {
      const result = await queryExecution(quries.select_user_id_query, [
        assigned_to,
      ]);
      if (result.rows.length) {
        return true;
      }
      return false;
    },
    { message: taskTableMessages.asignedto }
  ),
  dueDate: z.string().refine(
    async (duedate) => {
      const dueDateString = duedate;
      const currentDate = new Date();
      const dueDate = new Date(dueDateString);
      if (dueDate <= currentDate) {
        return false;
      }
      return true;
    },
    { message: taskTableMessages.duedate }
  ),
  status: z.string().refine(
    async (status) => {
      const project_status = status.toLowerCase();
      if (project_status == "pending" || project_status == "completed") {
        return true;
      }
      return false;
    },
    { message: taskTableMessages.status }
  ),
  project_id: z.number().refine(
    async (project_id) => {
      const result = await queryExecution(
        quries.select_project_id_query,
        [project_id]
      );
      if (result.rows.length) {
        return true;
      }
      return false;
    },
    { message: taskTableMessages.projectid }
  ),
});

export const updateTaskdetails = z
  .object({
    task_id: z.number().refine(
      async (id) => {
        const result = await queryExecution(quries.select_task_id_query, [
          id,
        ]);
        if (result.rows.length) {
          return true;
        }
        return false;
      },
      { message: taskTableMessages.id }
    ),
    status: z.string().refine(
      async (status) => {
        const project_status = status.toLowerCase();
        if (project_status == "pending" || project_status == "completed") {
          return true;
        }
        return false;
      },
      { message: taskTableMessages.status }
    ),
  })
  .refine(
    async (object) => {
      console.log("--------");
      const date = await queryExecution(
        "select duedate from  xx1489_task_t where task_id=:task_id",
        [object.task_id]
      );
      const status = object.status.toLowerCase();

      const duedate = new Date(date.rows[0]);
      const currentdate = new Date();
      console.log(duedate, currentdate);
      if (status === "pending") {
        if (duedate > currentdate) {
          return true;
        }
        return false;
      }
      return true;
    },
    { message: "Due date is completed" }
  );

export const deleteTaskdetails = z.object({
  task_id: z.number().refine(
    async (id) => {
      const result = await queryExecution(quries.select_task_id_query, [
        id,
      ]);
      if (result.rowsAffected) {
        return true;
      }
      return false;
    },
    { message: taskTableMessages.id }
  ),
});
