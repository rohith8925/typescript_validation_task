export const dbmessage = {
  connectingport: `👏 server is listening at port ${process.env.PORT}`,
};

export const queryMessage: any = {
  connectMessage: "👏 DataBase Connected Sucessfully",
  notconnectMessage: "😒 Unable to connect DataBase",
  readMessage: "👏 Records Reads Successfully",
  insertMessage: "👏 Records Inserted Successfully",
  updateMessage: "👏 Records Updated Sucessfully",
  deleteMessage: "👏 Records Deleted Sucessfully",
  tokenValidation: "Enter valid Token",
  tokenEnv: "Token key is not found in the '.env' file",
  validateUser: "🚫Unauthorize User",
};

export const userTableMessages = {
  id: "User id already exists",
  name: "User Name already exists",
  minimum: "Password must contain minimum 8 characters",
  maximum: "Password exceeding 16 characters",
  uppercase: "Password should have atleast 1 uppercase",
  lowercase: "Your password should have atleast 1 lowercase",
  numeric: "Password should contain atleast 1 number",
  specialcharacter: "No special characters found in your password",
};

export const projectTableMessages = {
  id: "Project id does not exists",
  name: "Project name already exists",
  nameminimum: "Project name should have atleat 5 characters",
  namemaximum: "Project name should not exceed more than 10 characters",
  descminimum: "Description should be more than 10 characters",
  descmaximum: "Description cannot exceed 50 characters",
};

export const taskTableMessages = {
  id: "project id does not exist in task table",
  asignedto: "User id does not exist in user table",
  projectid: "Project id does not exist in project table",
  duedate: "due date to ensure it's in the future.",
  status: "Status allowed only pending or completed",
};
