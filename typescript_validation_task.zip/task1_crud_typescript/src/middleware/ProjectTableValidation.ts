import { NextFunction, Request, Response } from "express";
import z from "zod";
import {
  deleteTableDetails,
  projectTableDetails,
  updateTableDetails,
} from "../module/ProjectTableSchema";

//insertProject
export async function insertprojectvalidate(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    await projectTableDetails.parseAsync(req.body);

    next();
  } catch (e) {
    if (e instanceof z.ZodError) {
      return res.status(200).json({ error: e.errors });
    }
    next(e);
  }
}

//updateProject
export async function updateprojectvalidate(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    await updateTableDetails.parseAsync(req.body);

    next();
  } catch (e) {
    if (e instanceof z.ZodError) {
      return res.status(200).json({ Error: e.errors });
    }
    next(e);
  }
}

//deleteProject
export async function deleteprojectvalidate(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    await deleteTableDetails.parseAsync(req.body);

    next();
  } catch (e) {
    if (e instanceof z.ZodError) {
      return res.status(200).json({ Error: e.errors });
    }
    next(e);
  }
}
