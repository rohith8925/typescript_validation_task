import { NextFunction, Request, Response } from "express";
import {
  deleteUserTableDetails,
  updateUserTableDetails,
  usertableDetails,
} from "../module/UserTableSchema";
import { z } from "zod";

//insertUser
export async function insertuservalidate(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    await usertableDetails.parseAsync(req.body);
    next();
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(200).json(error.errors[0].message);
    }
    next(error);
  }
}


//updateUser
export async function updateuservalidate(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    await updateUserTableDetails.parseAsync(req.body);

    next();
  } catch (e) {
    if (e instanceof z.ZodError) {
      return res.status(200).json({ error: e.errors });
    }
    next(e);
  }
}

//deleteUser
export async function deleteuservalidate(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    await deleteUserTableDetails.parseAsync(req.query);
    next();
  } catch (e) {
    if (e instanceof z.ZodError) {
      return res.status(200).json({ Error: e.errors });
    }
    next(e);
  }
}
