import { NextFunction, Request, Response } from "express";
import { taskTableDetails, updateTaskdetails } from "../module/TaskTableSchema";
import { z } from "zod";
import { deleteTableDetails } from "../module/ProjectTableSchema";

//insert
export async function inserttaskvalidate(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    await taskTableDetails.parseAsync(req.body);
    next();
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(200).json({ error: error.errors });
    }
    next(error);
  }
}

//update
export async function updatetaskvalidate(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    await updateTaskdetails.parseAsync(req.body);
    next();
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(200).json({ error: error.errors });
    }
    next(error);
  }
}

//delete
export async function deletetaskvalidate(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    await deleteTableDetails.parseAsync(req.body);
    next();
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(200).json({ error: error.errors });
    }
    next(error);
  }
}
