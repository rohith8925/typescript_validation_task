import { connect } from "../connection/dbconnection";

export async function queryExecution(query: string,object?: object,opts?:object) {
  const result = await connect.execute(query, object||{},opts||{});
  return result;
}
