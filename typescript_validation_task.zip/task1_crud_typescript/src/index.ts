import express from "express";
import { tsCrudRoute } from "./route/userRouter";
import { tsProjectCrudRoute } from "./route/projectRouter";
import { tsCrudTaskRoute } from "./route/taskRouter";
import { tsCrudAllDetailsRoute } from "./route/allTaskDetails";
import "dotenv/config";

const app = express();
app.use(express.json());
const port = process.env.PORT;


app.use("/user", tsCrudRoute);
app.use("/project",tsProjectCrudRoute);
app.use("/task",tsCrudTaskRoute)
app.use("/allDetails",tsCrudAllDetailsRoute)

app.listen(port, () => {
  console.log(`Server is listening at ${port}`);
});
