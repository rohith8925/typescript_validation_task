import { Router } from "express";
import {loginUserDetailsController,deleteUserDetailsController,getAllUserDetailsController,insertUserDetailsController,updateUserDetailsController} from "../Structure/Controller/UserTableController";
import {insertuservalidate,updateuservalidate,deleteuservalidate} from "../middleware/UserTableValidation";
import { validToken } from "../authorization/authorization";

export const tsCrudRoute = Router();

//usertable
tsCrudRoute.get("/loginUser",loginUserDetailsController)
tsCrudRoute.get("/getAllUserDetails", validToken,getAllUserDetailsController);
tsCrudRoute.post("/insertUserDetails",validToken,insertuservalidate,insertUserDetailsController);
tsCrudRoute.put("/updateUserDetails",validToken,updateuservalidate,updateUserDetailsController);
tsCrudRoute.delete("/deleteUserDetails",validToken,deleteuservalidate,deleteUserDetailsController
);







