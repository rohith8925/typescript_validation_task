import { Router } from "express";
import { validToken } from "../authorization/authorization";
import { deleteProjectDetailsController, getAllProjectDetailsController, insertProjectDetailsController, updateProjectDetailsController } from "../Structure/Controller/ProjectTableController";
import { deleteprojectvalidate, insertprojectvalidate, updateprojectvalidate } from "../middleware/ProjectTableValidation";

export const tsProjectCrudRoute = Router();

//ProjectDetails
tsProjectCrudRoute.get("/getAllProjectDetails", validToken,getAllProjectDetailsController);
tsProjectCrudRoute.post("/insertProjectDetails",validToken,insertprojectvalidate,insertProjectDetailsController);
tsProjectCrudRoute.put("/updateProjectDetails",validToken,updateprojectvalidate,updateProjectDetailsController);
tsProjectCrudRoute.delete("/deleteProjectDetails",validToken,deleteprojectvalidate,deleteProjectDetailsController);