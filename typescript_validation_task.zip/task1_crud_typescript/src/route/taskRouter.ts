import { Router } from "express";
import { validToken } from "../authorization/authorization";
import { deleteTaskDetailsController, getAllTaskDetailsController, insertTaskDetailsController, updateTaskDetailsController } from "../Structure/Controller/TaskTableController";
import { deletetaskvalidate, inserttaskvalidate, updatetaskvalidate } from "../middleware/TaskTableValidation";

export const tsCrudTaskRoute = Router();

//tasktable
tsCrudTaskRoute.get("/getAllTaskDetails", validToken,getAllTaskDetailsController);
tsCrudTaskRoute.post("/insertTaskDetails",validToken,inserttaskvalidate,insertTaskDetailsController);
tsCrudTaskRoute.put("/updateTaskDetails",validToken,updatetaskvalidate,updateTaskDetailsController);
tsCrudTaskRoute.delete("/deleteTaskDetails",validToken,deletetaskvalidate,deleteTaskDetailsController);