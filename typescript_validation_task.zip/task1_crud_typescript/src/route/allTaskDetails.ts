import { Router } from "express";
import { validToken } from "../authorization/authorization";
import { getAllTaskController } from "../Structure/Controller/getalltablescontroller";

export const tsCrudAllDetailsRoute = Router();

//getalltask
tsCrudAllDetailsRoute.get("/getAllDetails", validToken,getAllTaskController);