import z from "zod";
import {
  deleteTableDetails,
  projectTableDetails,
  updateTableDetails,
} from "../module/ProjectTableSchema";

export type projecttable_type = z.infer<typeof projectTableDetails>;

export type insert_projecttable_type = z.infer<typeof projectTableDetails>;

export type update_projecttable_type = z.infer<typeof updateTableDetails>;

export type delete_projecttable_type = z.infer<typeof deleteTableDetails>;
