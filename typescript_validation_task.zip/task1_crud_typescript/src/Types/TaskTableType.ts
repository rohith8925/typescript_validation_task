import {
  deleteTaskdetails,
  taskTableDetails,
  updateTaskdetails,
} from "../module/TaskTableSchema";
import z from "zod";
import { allTaskDetails } from "../module/getalltablesschema";

export type tasktable_type = z.infer<typeof taskTableDetails>;

export type insert_tasktable_type = z.infer<typeof taskTableDetails>;

export type update_tasktable_type = z.infer<typeof updateTaskdetails>;

export type delete_tasktable_type = z.infer<typeof deleteTaskdetails>;

export type display_alltask_type = z.infer<typeof allTaskDetails>;
