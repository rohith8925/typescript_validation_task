import {
  deleteUserTableDetails,
  updateUserTableDetails,
  usertableDetails,
} from "../module/UserTableSchema";
import z from "zod";

export type message = {
  message: string;
  rowsAffected: Number;
};

export type usertable_type = z.infer<typeof usertableDetails>;

export type insert_usertable_type = z.infer<typeof usertableDetails>;

export type update_usertable_type = z.infer<typeof updateUserTableDetails>;

export type delete_usertable_type = z.infer<typeof deleteUserTableDetails>;
