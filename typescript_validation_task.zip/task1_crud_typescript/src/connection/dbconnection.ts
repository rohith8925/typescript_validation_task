import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT
import { queryMessage } from "../messages/message";

export let connect: any;
async function dbConn() {
  try {
    connect = await oracledb.getConnection({
      user: process.env.USER_NAME,
      password: process.env.PASSWORD,
      connectString: process.env.CONNECTION_STRING,
    });
    console.log(queryMessage.connectMessage);
    return connect;
  } catch (error) {
    console.log("------------", error);
  }
}

dbConn();
